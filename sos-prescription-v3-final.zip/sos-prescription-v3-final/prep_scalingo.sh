#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WEB_DIR="${ROOT_DIR}/web"
PLUGIN_DIR="${WEB_DIR}/wp-content/plugins/sos-prescription-v3"
TMP_DIR="$(mktemp -d)"
WP_TARBALL_URL="https://wordpress.org/latest.tar.gz"

cleanup() {
  rm -rf "${TMP_DIR}"
}
trap cleanup EXIT

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "Missing required command: $1" >&2
    exit 1
  }
}

need_cmd tar
need_cmd composer
need_cmd npm
if command -v curl >/dev/null 2>&1; then
  DL_CMD=(curl -fsSL "${WP_TARBALL_URL}" -o "${TMP_DIR}/wordpress.tar.gz")
elif command -v wget >/dev/null 2>&1; then
  DL_CMD=(wget -qO "${TMP_DIR}/wordpress.tar.gz" "${WP_TARBALL_URL}")
else
  echo "Missing curl or wget" >&2
  exit 1
fi

mkdir -p "${WEB_DIR}/wp-content/plugins"
if [[ ! -d "${PLUGIN_DIR}" ]]; then
  echo "Plugin directory not found: ${PLUGIN_DIR}" >&2
  exit 1
fi

PLUGIN_BACKUP="${TMP_DIR}/sos-prescription-v3"
cp -a "${PLUGIN_DIR}" "${PLUGIN_BACKUP}"

echo "> Downloading latest WordPress from ${WP_TARBALL_URL}"
"${DL_CMD[@]}"

echo "> Extracting WordPress into web/"
mkdir -p "${TMP_DIR}/wp"
tar -xzf "${TMP_DIR}/wordpress.tar.gz" -C "${TMP_DIR}/wp"
cp -a "${TMP_DIR}/wp/wordpress/." "${WEB_DIR}/"

mkdir -p "${WEB_DIR}/wp-content/plugins"
rm -rf "${PLUGIN_DIR}"
cp -a "${PLUGIN_BACKUP}" "${PLUGIN_DIR}"

echo "> Generating composer.lock at repository root"
(
  cd "${ROOT_DIR}"
  composer update --no-interaction --prefer-dist
)

echo "> Generating medlab-worker/package-lock.json and installing worker dependencies"
(
  cd "${ROOT_DIR}/medlab-worker"
  npm install
)

echo
echo "Preparation complete."
echo "Next steps:"
echo "  1. Commit composer.lock and medlab-worker/package-lock.json"
echo "  2. Ensure ML_WORKER_BASE_URL points to a Worker URL reachable from the web process"
echo "     (Private Networks or a dedicated routable worker app on Scalingo)"
echo "  3. Deploy with the provided .buildpacks, Aptfile and Procfile"
